<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-sm-8 m-auto ">
                <div class=" panel ">
                    <p><?php echo e($opportunity->user_id); ?></p>
                    <div class="img-p-l m-auto">
                        <img src="/storage/<?php echo e($opportunity->media); ?>" alt="media" class="img-fluid">
                    </div>
                    <div class="text-center pt-3">
                        <div>
                            <p class="font-weight-bold"><?php echo e($opportunity->title); ?></p>
                        </div>
                        <div>
                            <p class=""><?php echo e($opportunity->description); ?></p>
                        </div>
                        <div class="row align-text-bottom">
                            <div class="col-sm-6"><?php echo e($opportunity->open); ?></div>
                            <div class="col-sm-6"><?php echo e($opportunity->close); ?></div>
                        </div>
                        <div>
                            <?php if($opportunity->take_app): ?>


                                <form action="/apply/<?php echo e($opportunity->id); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row ">
                                        <div class="col-sm-6 form-group text-left">
                                            <label for="resume">Resume (Optional)</label>
                                            <input type="file" name="resume" id="resume" class="form-control-file <?php $__errorArgs = ['resume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['resume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-sm-6 form-group text-left">
                                            <label for="cover_letter">Cover Letter (Optional)</label>
                                            <input type="file" name="cover_letter" id="cover_letter" class="form-control-file <?php $__errorArgs = ['cover_letter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['cover_letter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group text-center">
                                        <button type="submit" class="btn btn-primary ">Apply Now</button>
                                    </div>
                                </form>
                                <?php else: ?>
                                <div class="form-group text-center">
                                    <a href="<?php echo e($opportunity->link); ?>" target="_blank"><button type="submit" class="btn btn-primary btn-lg"><span class="fa fa-external-link"></span>Apply</button></a>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_projects\gradEdIn\resources\views/opportunities/show.blade.php ENDPATH**/ ?>