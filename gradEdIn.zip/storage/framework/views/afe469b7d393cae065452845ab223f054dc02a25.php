<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-sm-8 m-auto ">
                    <?php if(Session::has('msg')): ?>
                        <div class="alert alert-info">
                            <p><?php echo e(Session::get("msg")); ?>  </p>
                        </div>
                    <?php endif; ?>
                <div class="top-display">My Applications</div>
                <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="row panel mb-3">
                        <div class="col-sm-4">
                            <img src="/storage/<?php echo e($application->opportunity->media); ?>" alt="media" class=" card-img">
                        </div>
                        <div class="col-sm-8">
                            <p class="font-weight-bold"><a href="/opportunities/<?php echo e($application->opportunity->id); ?>"><?php echo e($application->opportunity->title); ?></a></p>
                            <p class=""><?php echo e($application->opportunity->description); ?></p>




                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        None found
                    <?php endif; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_projects\gradEdIn\resources\views/user/applications.blade.php ENDPATH**/ ?>