<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-sm-8 m-auto ">
                    <?php if(Session::has('msg')): ?>
                        <div class="alert alert-info">
                            <p><?php echo e(Session::get("msg")); ?>  </p>
                        </div>
                    <?php endif; ?>
                <div class="top-display">Opportunities</div>
                <?php $__empty_1 = true; $__currentLoopData = $opportunities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opportunity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="row panel mb-3">
                        <div class="col-sm-4">
                            <img src="/storage/<?php echo e($opportunity->media); ?>" alt="media" class=" card-img">
                        </div>
                        <div class="col-sm-8">
                            <p class="font-weight-bold"><a href="/opportunities/<?php echo e($opportunity->id); ?>"><?php echo e($opportunity->title); ?></a></p>
                            <?php if(strlen($opportunity->description) > 100): ?>
                                <?php echo e(substr($opportunity->description,0,100)); ?>

                                <span class="read-more-show hide_content">More<i class="fa fa-angle-down"></i></span>
                                <span class="read-more-content"> <?php echo e(substr($opportunity->description,100,strlen($opportunity->description))); ?>

                                <span class="read-more-hide hide_content">Less <i class="fa fa-angle-up"></i></span> </span>
                            <?php else: ?>
                                <?php echo e($opportunity->description); ?>

                            <?php endif; ?>



                            <div class="row align-text-bottom mt-2">
                                <div class="col-sm-6 small font-weight-bold">Opened: <?php echo e(date("D, d M Y", strtotime($opportunity->open))); ?></div>
                                <div class="col-sm-6 small font-weight-bold">Closes: <?php echo e(date("D, d M Y", strtotime($opportunity->close))); ?></div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        None found
                    <?php endif; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('read_more'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('.read-more-content').addClass('hide_content')
            $('.read-more-show, .read-more-hide').removeClass('hide_content')

            // Set up the toggle effect:
            $('.read-more-show').on('click', function(e) {
                $(this).next('.read-more-content').removeClass('hide_content');
                $(this).addClass('hide_content');
                e.preventDefault();
            });

            // Changes contributed by @diego-rzg
            $('.read-more-hide').on('click', function(e) {
                var p = $(this).parent('.read-more-content');
                p.addClass('hide_content');
                p.prev('.read-more-show').removeClass('hide_content'); // Hide only the preceding "Read More"
                e.preventDefault();
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_projects\gradEdIn\resources\views/opportunities/index.blade.php ENDPATH**/ ?>