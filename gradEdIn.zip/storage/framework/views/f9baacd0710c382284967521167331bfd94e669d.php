<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-sm-8 m-auto ">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="text-right">

                            <img src="/storage/uploads/profile/image/cSKfGPIOAwVlUtS6PkJd9a0WAQ7xM8AetsV1TvUD.jpeg" alt="avatar" class="avatar">
                        </div>

                    </div>

                    <div class="col-sm-8 p-20">
                        <div>
                            <p class="top-display text-left"><?php echo e($profile->first_name); ?>, <?php echo e(strtoupper($profile->last_name)); ?>  </p>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $profile)): ?>
                                <p><a href="/profile/edit/<?php echo e($profile->id); ?>"><button class="btn btn-primary">Edit Profile</button></a></p>
                            <?php endif; ?>
                            <?php $__empty_1 = true; $__currentLoopData = $profile->certifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <span class="fa fa-check"><?php echo e($certification->$certification); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <?php endif; ?>
                        </div>
                        <div>
                            <p class=""><?php echo e($profile->bio); ?></p>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <p><a href="/storage/<?php echo e($profile->cv); ?>" target="_blank"><span class="fa fa-link"></span> CV</a></p>
                            </div>
                            <div class="col-sm-6">
                                <p><a href="/storage/<?php echo e($profile->cover_letter); ?>" target="_blank"><span class="fa fa-link"></span> Cover Letter</a></p>
                            </div>
                        </div>
                    </div>
                    <hr>
                </div>
                <div class="row ml-5">
                    <div class="col-sm-6">
                        <p class="font-weight-bold">Academic History</p>

                    <?php $__empty_1 = true; $__currentLoopData = $academic_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <p><?php echo e($ach->school); ?></p>
                            <p><?php echo e($ach->course); ?></p>
                            <p><?php echo e($ach->certification); ?></p>

                                <div class="small"><?php echo e($ach->start); ?> - <?php echo e($ach->end); ?></div>



                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            None
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-6">
                        <p class="font-weight-bold">Skills and Competencies</p>
                        <?php $__empty_1 = true; $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <p><?php echo e($skill->skill); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <?php endif; ?>
                    </div>
                </div>
                <div class="row ml-5">








                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_projects\gradEdIn\resources\views/profile/show.blade.php ENDPATH**/ ?>