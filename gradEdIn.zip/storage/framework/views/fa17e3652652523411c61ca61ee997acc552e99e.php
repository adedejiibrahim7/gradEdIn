<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-sm-8 m-auto ">
                    <?php if(Session::has('msg')): ?>
                        <div class="alert alert-info">
                            <p><?php echo e(Session::get("msg")); ?>  </p>
                        </div>
                    <?php endif; ?>

                <?php $__empty_1 = true; $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="row panel mb-3">
                        <div class="col-sm-4">
                            <img src="/storage/<?php echo e($profile->avatar); ?>" alt="media" class=" card-img">
                        </div>
                        <div class="col-sm-8">
                            <p class="font-weight-bold"><a href="/opportunities/<?php echo e($profile->id); ?>"><?php echo e($profile->first_name); ?>, <?php echo e(strtoupper($profile->last_name)); ?></a></p>
                            <?php if(strlen($profile->bio) > 150): ?>
                                <?php echo e(substr($profile->bio,0,150)); ?>

                                <span class="read-more-show hide_content">More<i class="fa fa-angle-down"></i></span>
                                <span class="read-more-content"> <?php echo e(substr($profile->bio,150,strlen($profile->bio))); ?>

                                <span class="read-more-hide hide_content">Less <i class="fa fa-angle-up"></i></span> </span>
                            <?php else: ?>
                                <?php echo e($profile->bio); ?>

                            <?php endif; ?>


                            <div class="row align-text-bottom">
                                <div class="col-sm-6">
                                    <?php if($profile->application[0]->resume != "document"): ?>
                                        <a href="/storage/<?php echo e($profile->application[0]->resume); ?>">Resume</a>
                                    <?php else: ?>
                                        <a href="/storage/<?php echo e($profile->cv); ?>">CV</a>
                                    <?php endif; ?>
                                </div>
                                <div class="col-sm-6">
                                    <?php if($profile->application[0]->cover_letter != "document"): ?>
                                        <a href="/storage/<?php echo e($profile->application[0]->cover_letter); ?>">Cover Letter</a>
                                    <?php else: ?>
                                        <a href="/storage/<?php echo e($profile->cover_letter); ?>">Cover Letter (General)</a>
                                    <?php endif; ?>
                                </div>
                                
                                
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        None found
                    <?php endif; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('read_more'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('.read-more-content').addClass('hide_content')
            $('.read-more-show, .read-more-hide').removeClass('hide_content')

            // Set up the toggle effect:
            $('.read-more-show').on('click', function(e) {
                $(this).next('.read-more-content').removeClass('hide_content');
                $(this).addClass('hide_content');
                e.preventDefault();
            });

            // Changes contributed by @diego-rzg
            $('.read-more-hide').on('click', function(e) {
                var p = $(this).parent('.read-more-content');
                p.addClass('hide_content');
                p.prev('.read-more-show').removeClass('hide_content'); // Hide only the preceding "Read More"
                e.preventDefault();
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_projects\gradEdIn\resources\views/applications/index.blade.php ENDPATH**/ ?>